Italiano: final A1 check
